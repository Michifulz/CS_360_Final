package com.example.Mobile2App_Final_Working;

import android.database.sqlite.SQLiteOpenHelper;

import android.content.ContentValues;

import android.database.sqlite.SQLiteDatabase;
import android.content.Context;


//this is the database to store events.
public class EventDatabaseManager extends SQLiteOpenHelper {

    static EventDatabaseManager sqLiteManager;


    private static final String DATABASE_NAME = "EVENT_DATABASE.db";

    private static final int VERSION=3;
    private static EventDatabaseManager instance;

    //creating the instance for the second database
    public static EventDatabaseManager getInstance(Context context) {
        if (instance == null) {
            instance = new EventDatabaseManager(context);
        }
        return instance;
    }

    private static final class EventTable{
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_EVENT = "event";
        private static final String COL_LOCATION = "location";
        private static final String EVENT_NOTES = "notes";
    }



    private EventDatabaseManager(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    //creating the database structure

    @Override
    public void onCreate (SQLiteDatabase db) {
        StringBuilder sql;
        sql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(EventDatabaseManager.EventTable.TABLE)
                .append("(")
                .append(EventDatabaseManager.EventTable.COL_ID)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(EventDatabaseManager.EventTable.COL_EVENT)
                .append(" TEXT, ")
                .append(EventDatabaseManager.EventTable.COL_LOCATION)
                .append(" TEXT, ")
                .append(EventDatabaseManager.EventTable.EVENT_NOTES)
                .append(" TEXT)");

        db.execSQL(sql.toString());
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


        //function for adding users to the database
    }
    public void addToDB(EventManager user)
    {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(EventDatabaseManager.EventTable.COL_ID, user.get_id());
        contentValues.put(EventDatabaseManager.EventTable.COL_EVENT, user.getEvent());
        contentValues.put(EventDatabaseManager.EventTable.COL_LOCATION, user.getLocation());
        contentValues.put(EventDatabaseManager.EventTable.EVENT_NOTES, user.getNotes());

        sqLiteDatabase.insert(EventDatabaseManager.EventTable.TABLE, null, contentValues);
    }




}
