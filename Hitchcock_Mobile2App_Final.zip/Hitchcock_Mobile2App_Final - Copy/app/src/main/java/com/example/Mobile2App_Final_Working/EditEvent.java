package com.example.Mobile2App_Final_Working;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.Switch;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;
import androidx.coordinatorlayout.widget.CoordinatorLayout;

public class EditEvent extends AppCompatActivity {


    Button button;
    CoordinatorLayout layout;

        @Override
        protected void onCreate(Bundle savedInstanceState) {
            super.onCreate(savedInstanceState);
            setContentView(R.layout.event_edit);

            //sends clicks from the create and delete events back to the home page

            Button create= (Button) findViewById(R.id.createEvent);
            Button delete= (Button) findViewById(R.id.deleteEvent);

            create.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    startActivity(new Intent(EditEvent.this,MainActivity.class));
                }

            });
            delete.setOnClickListener(new View.OnClickListener() {
                public void onClick(View v) {
                    startActivity(new Intent(EditEvent.this,MainActivity.class));
                }

            });


             Switch userSMS = (Switch) findViewById(R.id.toggelAlerts);

             Button addAlert = (Button)  findViewById(R.id.addAlarm);


//asking users to enable sms alerts
            addAlert.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {


                    Boolean switchState = userSMS.isChecked();
                    if(switchState) {

                        Toast.makeText(EditEvent.this, "Do you want to enable SMS alerts?", Toast.LENGTH_LONG).show();

                    }
                    }

            });


            }

        }

