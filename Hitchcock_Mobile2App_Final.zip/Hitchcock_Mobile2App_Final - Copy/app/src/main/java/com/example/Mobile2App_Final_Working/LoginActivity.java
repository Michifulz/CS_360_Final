package com.example.Mobile2App_Final_Working;

import static com.example.Mobile2App_Final_Working.DatabaseManager.sqLiteManager;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.Toast;

import androidx.appcompat.app.AppCompatActivity;

import com.example.Mobile2App_Final_Working.R;
import com.example.Mobile2App_Final_Working.DatabaseManager;

public class LoginActivity extends AppCompatActivity {

    private android.widget.EditText txtUsername;
    private android.widget.EditText txtPassword;

    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {

        super.onCreate(savedInstanceState);
        setContentView(R.layout.login_display);

        txtPassword = findViewById(R.id.passwordBox);
        txtUsername = findViewById(R.id.UsernameBox);



        // Check for a button click, lets the login button change the screen to the home screen

        Button LogIn= (Button) findViewById(R.id.loginButton); //calling login
        Button SignIn= (Button) findViewById(R.id.signUpButton); //calling signup

        LogIn.setOnClickListener(new View.OnClickListener() { //login click listener
            public void onClick(View v) {
                handeLogin(); //calls the verification when the login button is clicked
            }
        });

        SignIn.setOnClickListener(new View.OnClickListener() { //signin click listener
            public void onClick(View v) {
                startActivity(new Intent(LoginActivity.this,SignUpPage.class));
            }
        });


    }

    private void handeLogin(){

        String username = txtUsername.getText().toString();
        String password = txtPassword.getText().toString();


        DatabaseManager sqLiteManager = DatabaseManager.getInstance(this);


        if(DatabaseManager.getInstance(getApplicationContext()).authendicate(username,password)){


                    startActivity(new Intent(LoginActivity.this,MainActivity.class));


        }
        else{
            Toast.makeText(this, "try again", Toast.LENGTH_LONG).show();

        }

    }




}



