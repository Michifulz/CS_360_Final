package com.example.Mobile2App_Final_Working;

import java.util.ArrayList;

public class UserManager {
    public static ArrayList<UserManager> userArrayList = new ArrayList<>();
    public static String USER_EDIT_EXTRA =  "userEdit";

    private int _id;
    private String title;
    private String username;
    private String password;

//setters, getters and arrays for the database
    public UserManager(int id, String title, String password)
    {
        this._id = id;
        this.title = title;
        this.password = password;
    }

    public static UserManager getUserID(int passedUserID)
    {
        for (UserManager user : userArrayList)
        {
            if(user.get_id() == passedUserID)
                return user;
        }

        return null;
    }




    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getUsername() {
        return username;
    }

    public void setUsername(String username) {
        this.username = username;
    }

    public String getPassword() {
        return password;
    }

    public void setPassword(String password) {
        this.password = password;
    }


}
