package com.example.Mobile2App_Final_Working;

import java.util.ArrayList;

public class EventManager {

    //these are setters, getters and the array manager for the event page.
    public static ArrayList<EventManager> eventArrayList = new ArrayList<>();
    public static String EVEBT_EDIT_EXTRA =  "eventEdit";

    private int _id;
    private String event;
    private String location;
    private String notes;

    //setters, getters and arrays for the database
    public EventManager(int id, String title, String password)
    {
        this._id = id;
        this.event = title;
        this.location = password;
        this.notes = notes;
    }

    public static EventManager getEventID(int passedEventID)
    {
        for (EventManager event : eventArrayList)
        {
            if(event.get_id() == passedEventID)
                return event;
        }

        return null;
    }


    public int get_id() {
        return _id;
    }

    public void set_id(int _id) {
        this._id = _id;
    }

    public String getEvent() {
        return event;
    }

    public void setEvent(String event) {
        this.event = event;
    }

    public String getLocation() {
        return location;
    }

    public void setLocation(String location) {
        this.location = location;
    }

    public String getNotes() {
        return notes;
    }

    public void setNotes(String notes) {
        this.notes = notes;
    }



}
