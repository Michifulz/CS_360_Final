package com.example.Mobile2App_Final_Working;


import android.annotation.SuppressLint;
import android.content.ContentValues;
import android.database.Cursor;
import android.database.sqlite.SQLiteOpenHelper;
import android.database.sqlite.SQLiteDatabase;
import android.content.Context;
import android.os.Build;
import android.util.Log;


public class DatabaseManager extends SQLiteOpenHelper {


    static DatabaseManager sqLiteManager;



    private static final String DATABASE_NAME = "DATABASE.db";

    private static final int VERSION=2;
    private static DatabaseManager instance;

//creating the instance for the databasemanager
    public static DatabaseManager getInstance(Context context) {
        if (instance == null) {
            instance = new DatabaseManager(context);
        }
        return instance;
    }

    private static final class LoginTable{
        private static final String TABLE = "users";
        private static final String COL_ID = "_id";
        private static final String COL_USER = "username";
        private static final String COL_PASSWORD = "password";
    }



    private DatabaseManager(Context context) {
        super(context, DATABASE_NAME, null, VERSION);
    }

    //creating the database structure

    @Override
    public void onCreate (SQLiteDatabase db) {
        StringBuilder sql;
        sql = new StringBuilder()
                .append("CREATE TABLE ")
                .append(LoginTable.TABLE)
                .append("(")
                .append(LoginTable.COL_ID)
                .append(" INTEGER PRIMARY KEY AUTOINCREMENT, ")
                .append(LoginTable.COL_USER)
                .append(" TEXT, ")
                .append(LoginTable.COL_PASSWORD)
                .append(" TEXT)");

        db.execSQL(sql.toString());
    }
    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {


        //function for adding users to the database
    }
    public void addToDB(UserManager user)
    {
        SQLiteDatabase sqLiteDatabase = this.getWritableDatabase();
        ContentValues contentValues = new ContentValues();
        contentValues.put(LoginTable.COL_ID, user.get_id());
        contentValues.put(LoginTable.COL_USER, user.getUsername());
        contentValues.put(LoginTable.COL_PASSWORD, user.getPassword());

        sqLiteDatabase.insert(LoginTable.TABLE, null, contentValues);
    }

//autentication function

    public boolean authendicate(String username, String password){
        boolean isAuthenticated = false;

        SQLiteDatabase db = getReadableDatabase();

        String sql = "select * from users WHERE username = ? AND password = ? ";
        @SuppressLint("Recycle") Cursor cursor = db.rawQuery(sql, new String[]{username, password});

        if(cursor.moveToFirst()){
            isAuthenticated = true;
        }
        return isAuthenticated;
    }

}

