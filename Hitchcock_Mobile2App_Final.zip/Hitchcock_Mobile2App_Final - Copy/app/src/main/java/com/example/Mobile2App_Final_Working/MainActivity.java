package com.example.Mobile2App_Final_Working;

import static com.example.Mobile2App_Final_Working.R.*;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;

import com.example.Mobile2App_Final_Working.R;


public class MainActivity extends AppCompatActivity {

    Button button;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.event_display);

        //this links the home page to the edit page


        Button editButton= (Button) findViewById(id.button10);
        Button addButton= (Button) findViewById(id.addButton);
        editButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,EditEvent.class));
            }
        });

        addButton.setOnClickListener(new View.OnClickListener() {
            public void onClick(View v) {
                startActivity(new Intent(MainActivity.this,EditEvent.class));
            }
        });

//        deleButton.setOnClickListener(new View.OnClickListener() {
//            public void onClick(View v) {
//                startActivity(new Intent(MainActivity.this,EditEvent.class));
//            }
//        });

    }

}
