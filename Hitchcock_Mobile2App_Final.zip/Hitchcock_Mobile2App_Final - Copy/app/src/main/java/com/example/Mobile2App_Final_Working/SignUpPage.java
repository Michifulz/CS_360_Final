package com.example.Mobile2App_Final_Working;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

import androidx.appcompat.app.AppCompatActivity;
public class SignUpPage extends AppCompatActivity {


    Button button;

    private EditText getUsername, getPassword;
    private UserManager selectedUsername;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.sign_up);
        DatabaseManager sqLiteManager = DatabaseManager.getInstance(this);

        getUsername = findViewById(R.id.inputUsername);
        getPassword = findViewById(R.id.inputPassword);


        Button button= (Button) findViewById(R.id.button3); // click listener for signup button
        button.setOnClickListener(new View.OnClickListener() {






            public void onClick(View v) {

                Intent previousIntent = getIntent();
                int passedNoteID = previousIntent.getIntExtra(UserManager.USER_EDIT_EXTRA, -1);
                selectedUsername = UserManager.getUserID(passedNoteID);



                String username = String.valueOf(getUsername.getText());
                String password = String.valueOf(getPassword.getText());


//adding the new users to the database
                startActivity(new Intent(SignUpPage.this,MainActivity.class));

                if(selectedUsername == null){
                    int _id = UserManager.userArrayList.size();
                    UserManager newUser = new UserManager(_id, username, password);
                    UserManager.userArrayList.add(newUser);
                    sqLiteManager.addToDB(newUser);
                }

            }
        });

    }
}
